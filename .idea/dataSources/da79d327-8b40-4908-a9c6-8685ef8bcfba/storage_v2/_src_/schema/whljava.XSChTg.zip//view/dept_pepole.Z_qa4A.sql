CREATE VIEW dept_pepole AS
  SELECT
    `whljava`.`dept`.`name`   AS `name`,
    `whljava`.`dept`.`salary` AS `salary`,
    `whljava`.`pepole`.`sex`  AS `sex`,
    `whljava`.`pepole`.`old`  AS `old`
  FROM (`whljava`.`dept`
    JOIN `whljava`.`pepole` ON ((`whljava`.`dept`.`id` = `whljava`.`pepole`.`id`)))
  ORDER BY `whljava`.`dept`.`name`;

